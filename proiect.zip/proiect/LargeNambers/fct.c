#include "functions.h"
/*******************CONVERT_CHAR_TO_INT*************************************/

void convert_to_value(int length_first,char ch_first[],int first[]){
        int i, j;

        for (i = length_first - 1, j = 0; i >= 0; i--, j++){
                first[j] = ch_first[i] - '0';

        }


}
/***************************************************************************/
void inv(int v[], int dimension){

        int i,  temp;
        for (i = 0; i < dimension/2; i++){
                temp = v[i];
                v[i] = v[dimension - i -1];
                v[dimension - i - 1] = temp;
        }
}
/*****************************************************/
int max(int a, int b){

        if (a > b){
                return  a;
        } else {
                return b;
        }
}
/****************************************************/
int equal_large_number(int first[], int second[], int size_f, int size_s, int ok){

    int i;

    for (i = 0; i < size_f; i++){

        if (first[i] == second[i] && size_f == size_s){
            ok = 0;
        } else {
            ok++;
        }
    }
    return ok;
}
/****************************************************/
void zero(int b[], int f, int g, int r[]){
        int i;
        for (i = 0; i < f - g; i++){
                r[i] = 0;
        }

        for (i = 0; i < f; i++){
                r[f - g + i] = b[i];
        }

}



/************************ADDITION_TWO_LARGE_NUMBERS*************************/
void addition_two_large_numbers(int a[], int pre[],  int result[], int sum[], int max_length){
        int i;

        for (i = 0; i < max_length; i++){
                sum[i] = a[i] + pre[i];
        }

        for (i = max_length  - 1; i >= 0; i--){
                 if (sum[i] >= 10 && i != 0){
                        result[i] = sum[i]%10;
                        sum[i-1] = sum[i - 1] + sum[i] /10;

                } else {
                        result[i] = sum[i];
                }
        }

}


/*********************SUBTRACTION_TWO_LARGE_NUMBERS*************************/

void subtraction_two_large_numbers(int a[], int z[], int result[], int dimension){

        int i;

        for (i = dimension -1; i >= 0; i--){
                if (a[i] < z[i] && i != 0){
                        a[i-1] = a[i-1] -1;
                        result[i] = a[i] + 10 - z[i];
                } else{
                        result[i] = a[i] - z[i];

                }
        }

}

/*********************DIVISION_TWO_LARGE_NUMBERS****************************/

void * division_two_large_numbers(char a[],unsigned long b, int la){
    char c[1000];
    int i,k=0,flag=0;
    unsigned long temp=1,reminder;



    for(i = 0; i <= la; i++){
         a[i] = a[i] - 48;
    }

    temp = a[0];
    reminder = a[0];
    for(i = 1; i <= la; i++){
         if(b <= temp){
             c[k++] = temp/b;
             temp = temp % b;
             reminder = temp;
             temp =temp * 10 + a[i];
             flag=1;

         }
         else{
             reminder = temp;
             temp =temp * 10 + a[i];
             if(flag == 1)
                 c[k++] = 0;
         }
    }

    for(i = 0; i < k; i++){
         c[i] = c[i] + 48;
    }
    c[i] = '\0';
    printf(" %s AND REMINDER IS %lu", c, reminder);

}
/***************************************************************************/


void multiply_two_lage_numbers(int length_first, int length_second, int first[], int second[], int result[]){

    int i, j;
    int temp;//temporary variable

    for (i = 0; i < length_second; i++){
            for (j = 0; j < length_first; j++){
                        result[i + j] = result[i + j] + second[i] * first[j];
            }
    }

    for (i = 0; i < length_first + length_second; i++){
                temp = result[i]/10;
                result[i] = result[i]%10;
                result[i + 1] = result[i + 1] + temp;
    }


}
void display_to_difference(int a[], int dimension){
        int i;
        for (i = 0; i < dimension; i++){
                printf("%d", a[i]);
        }
}
/*************************************************************************/
void display(int result[], int length){
    int i;


    for (i = length; i >= 0; i--){
            if (result[i] > 0){
                break;
            }
    }

    for (;i>=0;i--){
            printf("%d", result[i]);
    }
}
void display_to_add(int result[],int dimension){
    int i;

    for (i = 0; i < dimension; i++){
        printf("%d", result[i]);
    }
}
/*************************************************************************/
void SQUARE_ROOT(int a[], int b[], int m, int result[]){
int c = 0;
        int ok = 1;
        int unit =0;
        int j, k = 0;
        int i,f;
        while(k < m){
    if ( m % 2 == 1){
            b[0] = a[0];
            for (i = 1,j = 1; i < m - 1, j <= (m + 1)/2;i+=2, j++){
                                b[j] = a[i ] * 10 + a[i + 1];
            }
    } else {
            if (m %2 == 0){
                    for (i = 0, j =0; i < m -1, j <= (m + 1)/2; i+=2, j++){
                                b[j] = a[i] * 10 + a[i + 1];
                    }
            }
        }
    k++;
}

for (i =0 ; i < (m + 1)/2; i++){
 printf("%d ", b[i]);
 }
 if (i == 0){
            result[0] = 0;
        }


 while ((unit < b[i])){

    if ((c * c <= b[i]) && ((c+1)*(c+1) > b[i - 1])){
            result[ok] = result[ok - 1] * 10 + c;
            ok++;
            break;
    } else {
        c++;
        if (c * c > b[i - 1]){
            break;
        }
    }
    if ((c * c >= b[i]) && ((c-1) * (c-1) > b[i - 1])){
            result[ok] = result[ok - 1] * 10 + c;
            ok++;
            break;
    } else {
        c--;
    }

    printf("%d", c);

    
    b[i+1] = (b[i] - c * c) * 100 + b[i+1];
   
    f = result[ok] * 2;

    c = b[i + 1] /10 /f;
    unit = (f * 10 + c)*c;
    i++;


}
}
