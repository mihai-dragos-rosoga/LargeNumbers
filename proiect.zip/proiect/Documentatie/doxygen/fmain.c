///\file main.c
///\brief C project for large intger operation
///
///Created by Mihai ROSOGA on 20/06/2017
///About use large integers in :adding, multipyng, square_root, division, substracion
#include "function.h"

int main(){
	//\fn int main()
    	///\brief Main function.
    	/// Function calls of sum and sub imported from functions.h
    	/// Function calls of multiply and division imported from functions.h
    	/// Function calls of square root imported from functions.h
    	
    	///\var message A simple variable containing a message
       char ch1[101], ch2[101];// variabile de intrare
       char *c;
       int x[100], y[100];//variabile de convertire char to int
       int r[200] = {0};//returnarea rezultatului
       int w[100] = {0};
       int i, k, f_e;//index
       int s[100];
       int t[100];
       int dim1, dim2, m, d, l;//dimensiuni, max, min, diferenta dintre cele doua
       unsigned long n2;// variabila folosita pentru functia division

       printf("Please enter the first number! \n");
       scanf("%s", ch1);

       printf("\n Please enter the second number and replay number\n");
       scanf("%s", ch2);
       scanf("%lu", &n2);

       dim1 = strlen(ch1);
       dim2 = strlen(ch2);

       l = dim1 + dim2;

       if (dim1 > dim2){
            d = dim1 - dim2;
       } else {
            d = dim2 - dim1;
       }


       convert_to_value(dim1, ch1, x);
       convert_to_value(dim2, ch2, y);


       multiply_two_lage_numbers(dim1, dim2, x, y, r);
       printf("\nRESULT FOR MULTIPLICATION TWO LARGE NUMBERS: ");
       display(r,l);
       printf("\n");

       m = max(dim1, dim2);

       inv(x, dim1);
       inv(y, dim2);

       f_e = equal_large_number(x, y, dim1, dim2, k);
       printf("\n %d \n", f_e);

       if (dim1 > dim2){
            zero(y, dim1, dim2,w);
            printf("\nRESULT FOR ADDITION TWO LARGE NUMBERS: ");
            addition_two_large_numbers( x, w, r, s, m);
            display_to_add(r, m);

            printf("\n");

            printf("\nRESULT FOR SUBTRACTION TWO LARGE NUMBERS: ");
            subtraction_two_large_numbers(x, w, r, m);
            display_to_difference(r, m);
       } else {
            zero(x, dim2, dim1, w);
            printf("\nRESULT FOR ADDITION TWO LARGE NUMBERS: ");
            addition_two_large_numbers(y, w, r, s, m);
            display_to_add(r,m);

            printf("\n");

            printf("\nRESULT FOR SUBTRACTION TWO LARGE NUMBERS: -");
            subtraction_two_large_numbers(y, w, r, m);
            display_to_difference(r, m);
       }
       printf("\n");

       printf("\nRESULT FOR DIVISION OF TWO LARGE NUMBERS IS ");
       c = division_two_large_numbers(ch1, n2, dim1);

       printf("\n");
       SQUARE_ROOT(x,t ,m, r);
       printf("\nRESULT FOR SQUARE ROOT OF  LARGE NUMBER IS ");
       display_to_add(r,m);
       printf("\n");


   return 0;
}

﻿
