///\file function.h
///\brief C library for basic mathematic functions.
///
///Created by Mihai ROSOGA 0n 20.06.2017
///Implements adding, substracting, multiplyng, division, square root.

//#ifndef MAIN_H_INCLUDED
//#define MAIN_H_INCLUDED
#include<stdio.h>
#include <stdlib.h>
#include <string.h>
void convert_to_value(int length_first,char ch_first[],int first[]);
void inv(int v[], int dimension);
int max(int a, int b);
int equal_large_number(int first[], int second[], int size_f, int size_s, int ok);
void zero(int b[], int f, int g, int r[]);
void addition_two_large_numbers(int a[], int pre[],  int result[], int sum[], int max_length);
void subtraction_two_large_numbers(int a[], int z[], int result[], int dimension);
void * division_two_large_numbers(char a[],unsigned long b, int la);
void multiply_two_lage_numbers(int length_first, int length_second, int first[], int second[], int result[]);
void display_to_difference(int a[], int dimension);
void display(int result[], int length);
void display_to_add(int result[],int dimension);
void SQUARE_ROOT(int a[], int b[], int m, int result[]);
//#endif // FUNCTIONS_H_INCLUDED﻿﻿
